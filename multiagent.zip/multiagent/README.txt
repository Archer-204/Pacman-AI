Minimax: python pacman.py -p MinimaxAgent -l testClassic -g DirectionalGhost
Minimax with big maze:  python pacman.py -p MinimaxAgent
Alpa-Beta Pruning: change the MinimaxAgent to AlphaBetaAgent
